package com.ust.pms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UstSpingmvcProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
