package com.ust.pms.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ust.pms.model.Cart;
import com.ust.pms.repository.CartRepository;

@SpringBootTest
class CartServiceTest {

	
	
	@Autowired
	 CartService cartService;
	
	@BeforeEach
	public void setUp() throws Exception {
	
	}

	@AfterEach
	public void tearDown() throws Exception {
	}

//	@Test
//	public void testDeleteCart() {
//		
//	}

	@Test
	public void testUpdateCart() {
		boolean result = true;
		Cart cart = new Cart(100, "Hat", 6, 800);
		cartService.saveCart(cart);
		int cId = cart.getProductId();
		cart = new Cart(cId, "Hat", 6, 800);
		cartService.updateCart(cart);
		cartService.deleteCart(cart);
		assertEquals(true, result);
	}

//	@Test
//	public void testSaveCart() {
//		Cart cart = new Cart(100, "Hat", 6, 800);
//		cartService.saveCart(cart);
//		int cId = cart.getProductId();
//		cartService.deleteCart(cart);
//		assertEquals("cartproduct", cart.getProductName());
//
//	}
	 
	@Test
	public void testGetCartDetails() {
		List<Cart> carts = cartService.getCartDetails();
		assertTrue(carts.size() > 0);
	}

	
	@Test
	public void testGetCart() {
		List<Cart> cartItem = (List<Cart>) cartService.getCartDetails();
		int cartItemId = cartItem.get(0).getProductId();
		Cart rtvCart = (Cart) cartService.getCart(cartItemId);
		assertEquals(cartItemId, rtvCart.getProductId());
	}

	/*
	 * @Test public void testIsCartExist() { fail("Not yet implemented"); }
	 * 
	 * @Test public void testDeleteCartById() { fail("Not yet implemented"); }
	 * 
	 * @Test public void testSend() { fail("Not yet implemented"); }
	 */

}
