package com.ust.pms.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.ust.pms.model.Cart;
import com.ust.pms.model.Product;
import com.ust.pms.repository.CartRepository;
import com.ust.pms.repository.ProductRepository;

@Service
public class CartService implements MailService {

	@Autowired
	CartRepository cartRepository;

	public void deleteCart(Cart Cart) {

		cartRepository.delete(Cart);
	}

	public void updateCart(Cart Cart) {

		cartRepository.save(Cart);
	}
	/*
	 * public void saveCart(int productId) {
	 * 
	 * Product product = productService.getProduct(productId); Cart cart =
	 * this.getCart(product.getProductId()); Cart productInCart = new
	 * Cart(product.getProductId(), product.getProductName(),
	 * product.getQuantityOnHand(), product.getPrice()); if(cart == null){
	 * productInCart.setQuantityOnHand(1); } else{ int quantity =
	 * productInCart.getQuantityOnHand();
	 * productInCart.setQuantityOnHand(++quantity); }
	 * cartRepository.save(productInCart); int quantityInStore =
	 * product.getQuantityOnHand(); product.setQuantityOnHand(--quantityInStore);
	 * productRepository.save(product); }
	 * 
	 * public void saveCart(Product product) {
	 * 
	 * //cartRepository.save(product); Cart cart =
	 * this.getCart(product.getProductId()); Cart productInCart = new
	 * Cart(product.getProductId(), product.getProductName(),
	 * product.getQuantityOnHand(), product.getPrice()); if(cart == null){
	 * productInCart.setQuantityOnHand(1); } else{ int quantity =
	 * productInCart.getQuantityOnHand();
	 * productInCart.setQuantityOnHand(++quantity); }
	 * cartRepository.save(productInCart); int quantityInStore =
	 * product.getQuantityOnHand(); product.setQuantityOnHand(--quantityInStore);
	 * productRepository.save(product);
	 * 
	 * }
	 */
	public void saveCart(Cart cart) {
		cartRepository.save(cart);
	}

	public List<Cart> getCartDetails() {
		return (List<Cart>) cartRepository.findAll();
	}

	public Cart getCart(int CartId) {
		Optional<Cart> Cart = cartRepository.findById(CartId);
		return Cart.get();
	}

	public boolean isCartExist(int CartId) {

		return cartRepository.existsById(CartId);
	}

	public void deleteCartById(int cartId) {

		cartRepository.deleteById(cartId);
	}

	@Autowired
	private JavaMailSender javaMailSender;

	@Override
	public void send(String fromAddress, String toAddress, String subject, String content) throws Exception {
		MimeMessage mimeMessage = javaMailSender.createMimeMessage();
		MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, true);

		mimeMessageHelper.setFrom(fromAddress);
		mimeMessageHelper.setTo(toAddress);
		mimeMessageHelper.setSubject(subject);
		mimeMessageHelper.setText(content, true);
		mimeMessageHelper.setSentDate(new Date());

		javaMailSender.send(mimeMessage);
	}

}
