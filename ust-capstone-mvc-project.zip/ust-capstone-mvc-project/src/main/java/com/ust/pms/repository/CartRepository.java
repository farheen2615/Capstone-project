package com.ust.pms.repository;

import org.springframework.data.repository.CrudRepository;

import com.ust.pms.model.Cart;

public interface CartRepository extends CrudRepository<Cart,Integer>{

}
