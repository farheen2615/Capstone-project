package com.ust.pms.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ust.pms.model.Cart;
import com.ust.pms.model.Mail;
import com.ust.pms.model.Product;
import com.ust.pms.service.CartService;
import com.ust.pms.service.MailService;
import com.ust.pms.service.ProductService;
import com.ust.pms.util.UserUtil;

@Controller
public class CartController {

	@Autowired
	CartService cartService;

	@Autowired
	ProductService productService;
	@Autowired
	private MailService mailService;

	/*
	 * @RequestMapping("/saveCart/{productId}") public ModelAndView
	 * saveCart(@PathVariable("productId") int productId) {
	 * System.out.println("Inside savecart()"); cartService.saveCart(productId);
	 * ModelAndView view = new ModelAndView();
	 * view.setViewName("redirect:/productList"); return view; }
	 */

	@RequestMapping("/saveCart/{productId}")
	public String saveCart(@PathVariable("productId") int productId, Model model, Cart cart) {

		model.addAttribute("username", UserUtil.getUserName());
	

		ModelAndView mav = new ModelAndView();
		mav.setViewName("productList");

		List<Cart> cartList1 = cartService.getCartDetails();


		if (cartList1.size() < 10) {
			Product product = productService.getProduct(productId);
			cart = new Cart();
			cart.setProductId(product.getProductId());
			cart.setProductName(product.getProductName());
			cart.setPrice(product.getPrice());
			cart.setQuantityOnHand(cart.getQuantityOnHand()+1);
			product.setQuantityOnHand(product.getQuantityOnHand()-1);
			

			cartService.saveCart(cart);


		}else {
			model.addAttribute("moreproducts","exceed more than 10 products in cart page");
		}
		return "redirect:/productList";
		
		
	}

	@RequestMapping("/cartList")
	public ModelAndView checkProductList(Model model, Product products) {

		model.addAttribute("username", UserUtil.getUserName());
		model.addAttribute("command", products);

		ModelAndView mav = new ModelAndView();
		mav.setViewName("cart");

	
		List<Cart> cartList = cartService.getCartDetails();
		mav.addObject("cartList", cartList);

		return mav;

	}

	@RequestMapping("/deleteCart/{productId}")
	public String deleteCart(@PathVariable("productId") int productId, Model model, Product product) {

		Cart cart = cartService.getCart(productId);
		
		if(cart.getQuantityOnHand()==1)
		
		{
			product = new Product();
			product.setProductId(cart.getProductId());
			product.setProductName(cart.getProductName());
			product.setQuantityOnHand(product.getQuantityOnHand()+1);
			
			product.setPrice(cart.getPrice());
			productService.saveProduct(product);
			cartService.deleteCart(cart);
		}
		else
		{
			product.setProductId(cart.getProductId());
			product.setProductName(cart.getProductName());
			cart.setQuantityOnHand(cart.getQuantityOnHand()-1);
			product.setQuantityOnHand(product.getQuantityOnHand()+1);
			
			product.setPrice(cart.getPrice());
			productService.saveProduct(product);
			cartService.saveCart(cart);
			
		}
		

		

		return "redirect:/cartList";
	}

	
	
	

	@RequestMapping(value="/send",method = RequestMethod.GET)
	public String index(ModelMap modelMap) {
		modelMap.put("mail", new Mail());
		return "mailForm";
	}
	
	
	@RequestMapping(value = "/send", method = RequestMethod.POST)
	public String send(@ModelAttribute("mail") Mail mail, ModelMap modelMap) throws Exception {
		try {

			String content = "Name: " + mail.getName();
			content += "<br>Phone: " + mail.getPhone();
			content += "<br>Address: " + mail.getAddress();
			content += "<br>Subject: " + mail.getSubject();
			content += "<br>Content: " + mail.getContent();

			mailService.send(mail.getEmail(), "tufailahmedkhan@gmail.com", mail.getSubject(), content);
			modelMap.put("msg", "Mail Sent...");
		} catch (Exception e) {
			modelMap.put("msg", e.getMessage());
		}
		return "mailForm";
	}


}
