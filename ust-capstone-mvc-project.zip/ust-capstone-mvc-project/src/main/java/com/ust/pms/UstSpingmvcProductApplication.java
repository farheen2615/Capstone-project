package com.ust.pms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UstSpingmvcProductApplication {

	
	public static void main(String[] args) {
		SpringApplication.run(UstSpingmvcProductApplication.class, args);
	}

}
